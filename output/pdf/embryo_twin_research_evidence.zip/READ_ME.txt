Research evidence package for supervisory discussion, 8 November 2026.
Read report.pdf first. report.md is editable.
Includes notebooks, application and research code snapshots, selected summaries and small raw inputs for report figures.
The complete raw NPZ datasets and many nested run files remain in the original repository.
Embedded experiment SHA manifests can reference files not included in this selected package.
The manifest uses repository-relative source paths; archive layout flattens the report and figures for convenience.
No new simulations were run for report preparation.
